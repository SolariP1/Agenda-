﻿<?php
include("conecta.php");

$nomecli = $_POST["nomecli"];
$endereco = $_POST["endereco"]; 
$bairro = $_POST["bairro"];
$codcid = $_POST["codcid"];
$numeroTelefone = $_POST["numeroTelefone"];

$sql = "INSERT INTO tbl_clientes (cli_nome, cli_endereco, cli_bairro, cid_codigo) 
        VALUES ('".$nomecli."','".$endereco."','".$bairro."','".$codcid."')";

if (mysqli_query($conn, $sql)) {
      echo "Registro inserido com Sucesso!";
      
      $sqlcodigo ="SELECT MAX(cli_codigo)
                   FROM tbl_clientes";
      $querycodigo = mysqli_query($conn, $sqlcodigo);
      $linhacodigo = mysqli_fetch_array($querycodigo);              

      foreach ($numeroTelefone as $fone) {

            $sql_telefone = "INSERT INTO tbl_telefones (tel_numero, cli_codigo) 
                                 VALUES ('".$fone."','".$linhacodigo[0]."')";
            $queryfone = mysqli_query($conn, $sql_telefone);
      }
        

} else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>