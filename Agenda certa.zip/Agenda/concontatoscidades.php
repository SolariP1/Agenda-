<?php
if (isset($_POST["codcid"])){

$codcid = $_POST["codcid"];

if (!empty($codcid)) {
  
  include("conecta.php");

  $sqlconuf = "SELECT cli.cli_nome As Nome,
                                 cli.cli_endereco As Endereço,
                                 cli.cli_bairro  As Bairro,
                                 cid.cid_nome as Cidade,
                                 cid.cid_uf as Estado
                            FROM tbl_cidades cid, 
                                 tbl_clientes cli
                            WHERE cid.cid_codigo=cli.cid_codigo AND
                                  cid.cid_codigo = '$codcid'";
           $queryconuf = mysqli_query($conn,$sqlconuf);
           $resulta = mysqli_num_rows($queryconuf);
}
}


?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Agenda de Contato</title>
  
  <style>
   header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1em;
        }
   
    body {
      font-family: Arial, sans-serif;
    }
    fieldset {
      margin-bottom: 20px;
    }
    label {
      display: block;
      margin-bottom: 8px;
    }
    input, select {
      width: 100%;
      padding: 8px;
      box-sizing: border-box;
      margin-bottom: 16px;
    }
    table {
      border-collapse: collapse;
      width: 100%;
    }
    th, td {
      border: 1px solid #ddd;
      padding: 10px;
      text-align: left;
    }
    th {
      background-color: #f2f2f2;
    }
    .btn {
      cursor: pointer;
      padding: 6px 10px;
      background-color: #007bff;
      color: #fff;
      border: none;
      border-radius: 4px;
    }

    .btna {
      cursor: pointer;
      padding: 6px 10px;
      background-color: #08f281;
      color: #fff;
      border: none;
      border-radius: 4px;
    }

    nav {
            background-color: #555;
            padding: 1em;
        }

        nav a {
            color: #fff;
            text-decoration: none;
            padding: 0.5em 1em;
            margin-right: 10px;
            border-radius: 5px;
            background-color: #777;
        }

        nav a:hover {
            background-color: #999;
        }
        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 1em;
            bottom: 0;
            width: 100%;
        }
        img {
            border-radius: 50%;
            width: 100px;
            right: 10px;
            position: relative; 
            } 
           
          
  </style>
</head>
<body>

  <header>
   <h1>Agenda de Contatos</h1>
  </header>

  <nav>
        <a href="index.html">Home</a>
        <a href="contatos.php">Contatos</a>
        <a href="cidades.php">Cidades</a>
        <a href="consultas.html">Consultas</a>
  </nav>

  <h2>Cadastro de Cidades</h2>

  <?php
    include("conecta.php");
  ?>

 <div id="status"></div>
  
 <form name="cidadeform" action="concontatoscidades.php" method="post" id="cidadeform">
    <fieldset>
      <legend>Consulta de Contatos por Cidade</legend>
      
      <label for="uf1" id="uf1">Escolha a Cidade:</label>
      <select name="codcid" id="codcid" required>
      <option value=""></option>
      <?php
        $sqlcidades = "Select * from tbl_cidades order by cid_nome";
        $querycidades = mysqli_query($conn,$sqlcidades);
        $resulta1 = mysqli_num_rows($querycidades); 					
        if ($resulta1>0) {									  
             $i = 0;
             while ($linhacidade = mysqli_fetch_array($querycidades)) {
                 $i++;
      
            print"
             <option value=\"$linhacidade[0]\">$linhacidade[1]</option>
            ";
             }
            }    
        ?>
      </select>

      
    </fieldset>
    <input type="submit" value="Consultar">
  
  </form>

  
    <fieldset>
      <legend>Contatos da Cidade </legend>
      <table id="contatosTable">
        <thead>
          <tr>
            <th>Nome</th>
            <th>Endereço</th>
            <th>Bairro</th>
            <th>Cidade</th>
            <th>UF</th>
          </tr>
        </thead>
        <tbody>
        <?php
           include("conecta.php");
           
           if (isset($resulta)){
                                           
            if ($resulta>0) {									  
                $i = 0;
                while ($linhaconuf = mysqli_fetch_array($queryconuf)) {
                    $i++;
            ?>
          <tr>
            
             <?php
             print"
               <td>
                 <strong>$linhaconuf[0]</strong>
               </td>
               <td>
                  <strong>$linhaconuf[1]</strong>
               </td>
               <td>
                   $linhaconuf[2]
               </td>
               <td>
               $linhaconuf[3]
              </td>
              <td>
               $linhaconuf[4]
              </td>"; 
           }
			 }
            }
            ?>
          </tr>
        </tbody>
      </table>
      </fieldset>
   
  

<footer>
  <p>&copy; 2024 Agenda de Contatos</p>
</footer>

</body>

</html>
