﻿<?php
include("conecta.php");

$nome = $_POST["nomecid"];
$uf = $_POST["uf"]; 
$id = $_POST["id"];


$sql = "INSERT INTO tbl_cidades (cid_nome, cid_uf) 
        VALUES ('".$nome."','".$uf."')";

if (mysqli_query($conn, $sql)) {
      echo "Registro inserido com Sucesso!";
} else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>